"use strict";

$(function () {
  //==================================================================
  var lazyLoadInstance = new LazyLoad({
    elements_selector: ".lazy"
  });
  /* if (lazyLoadInstance) {
  	lazyLoadInstance.update();
  } */
  //==================================================================

  $('#my-menu').mmenu({
    extensions: {
      "all": ['theme-white', 'effect-menu-slide', "multiline", 'pagedim-black', 'position-right']
    },
    navbar: {
      title: "Меню"
    }
  });
  var api = $("#my-menu").data("mmenu");
  api.bind('open:finish', function () {
    $('.main-header__mbtn').addClass('active');
  });
  api.bind('close:finish', function () {
    $('.main-header__mbtn').removeClass('active');
  }); //==================================================================

  /* const swiper = new Swiper('.swiper', {
  	// Optional parameters
  	direction: 'vertical',
  	loop: true,
  		// If we need pagination
  	pagination: {
  		el: '.swiper-pagination',
  	},
  		// Navigation arrows
  	navigation: {
  		nextEl: '.swiper-button-next',
  		prevEl: '.swiper-button-prev',
  	},
  		// And if we need scrollbar
  	scrollbar: {
  		el: '.swiper-scrollbar',
  	},
  	breakpoints: {
  		// when window width is >= 320px
  		320: {
  			slidesPerView: 2,
  			spaceBetween: 20
  		},
  		// when window width is >= 480px
  		480: {
  			slidesPerView: 3,
  			spaceBetween: 30
  		},
  		// when window width is >= 640px
  		640: {
  			slidesPerView: 4,
  			spaceBetween: 40
  		}
  	}
  }); */
  //==================================================================

  var swNews = new Swiper('.news-sect__slider', {
    loop: true,
    speed: 600,
    navigation: {
      nextEl: '.news-sect__slider-next',
      prevEl: '.news-sect__slider-prev'
    },
    autoplay: {
      delay: 7000
    },
    breakpoints: {
      220: {
        slidesPerView: 1,
        spaceBetween: 10
      },
      480: {
        slidesPerView: 1,
        spaceBetween: 10
      },
      576: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 20
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 20
      },
      1200: {
        slidesPerView: 3,
        spaceBetween: 34
      }
    }
  });
  document.querySelectorAll('.ex-sect__slider').forEach(function (item, n) {
    var prev = "#ex-prev-".concat(n + 1);
    var next = "#ex-next-".concat(n + 1);
    var sw = new Swiper(item, {
      loop: true,
      speed: 600,
      navigation: {
        nextEl: prev,
        prevEl: next
      },
      autoplay: {
        delay: 6500
      },
      breakpoints: {
        220: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        480: {
          slidesPerView: 2,
          spaceBetween: 10
        },
        576: {
          slidesPerView: 2,
          spaceBetween: 10
        },
        768: {
          slidesPerView: 2,
          spaceBetween: 15
        },
        992: {
          slidesPerView: 3,
          spaceBetween: 10
        },
        1200: {
          slidesPerView: 3,
          spaceBetween: 20
        }
      }
    });
  }); //==================================================================

  var swMain = new Swiper('.main-sect__slider', {
    loop: true,
    speed: 700,
    slidesPerView: 1,
    spaceBetween: 10,
    effect: 'fade',
    fadeEffect: {
      crossFade: true
    },
    pagination: {
      el: '.main-sect__slider-pag',
      clickable: true
    },
    autoplay: {
      delay: 7000
    }
  }); //==================================================================

  var swProd = new Swiper('.prod-sect__slider .swiper', {
    loop: true,
    speed: 600,
    navigation: {
      nextEl: '.prod-sect__slider-next',
      prevEl: '.prod-sect__slider-prev'
    },
    autoplay: {
      delay: 6000
    },
    breakpoints: {
      220: {
        slidesPerView: 1,
        spaceBetween: 10
      },
      480: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      576: {
        slidesPerView: 2,
        spaceBetween: 10
      },
      768: {
        slidesPerView: 3,
        spaceBetween: 10
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 20
      },
      1200: {
        slidesPerView: 4,
        spaceBetween: 20
      }
    }
  }); //==================================================================

  $('input[name="phone"]').inputmask({
    "mask": "+79999999999" //"placeholder": "",
    //"clearMaskOnLostFocus": false

  }); //==================================================================

  /* $(window).scroll(function () {
  	if ($(window).scrollTop() >= $(window).height()) {
  		$('.scroll-up').addClass('active');
  	} else {
  		$('.scroll-up').removeClass('active');
  	}
  });
  $('.scroll-up').click(function () {
  	$('html, body').stop().animate({
  		scrollTop: 0
  	}, 'slow', 'swing');
  }); */
  //==================================================================
  //$('selector').css('height', '').equalHeights();
  //==================================================================

  /* $('.popup-with-zoom-anim').magnificPopup({
  	type: 'inline',
  		fixedContentPos: false,
  	fixedBgPos: true,
  		overflowY: 'auto',
  		closeBtnInside: true,
  	preloader: false,
  	
  	midClick: true,
  	removalDelay: 300,
  	mainClass: 'my-mfp-zoom-in'
  }); */
  //==================================================================

  $('[data-submenu] > a').click(function (e) {
    e.preventDefault();
    $(this).parent().toggleClass('active');
    $(this).next().stop().slideToggle(250);
  }); //==================================================================

  $('.faq-sect__item-title').click(function () {
    $(this).parent().toggleClass('active');
    $(this).next().stop().slideToggle(250);
  }); //==================================================================

  $('.main-nav__cbtn').click(function (e) {
    e.preventDefault();
    $('.main-sect__aside').stop().slideToggle(250);
  }); //==================================================================

  var mqTablets = window.matchMedia('(max-width: 768px)');

  function mqLaptopCallback(e) {
    if (e.matches) {//<768
    } else {
      //>768
      $('.main-sect__aside').attr('style', '');
    }
  }

  mqTablets.addEventListener('change', mqLaptopCallback); //==================================================================
});